% Sobel Edge Detection Without Built-in Functions in MATLAB

% Read the input image
inputImage = imread('C:\Users\user\Desktop/image.jpg'); % Replace 'image.jpg' with your image file
if size(inputImage, 3) == 3
    inputImage = rgb2gray(inputImage); % Convert to grayscale if the image is RGB
end

% Convert the image to double for calculations
inputImage = double(inputImage);

% Sobel kernels for horizontal (Gx) and vertical (Gy) gradients
Gx = [-1 0 1; -2 0 2; -1 0 1]; % Horizontal gradient
Gy = [-1 -2 -1; 0 0 0; 1 2 1]; % Vertical gradient

% Get the size of the image
[rows, cols] = size(inputImage);

% Initialize gradient matrices
gradientX = zeros(rows, cols); % Horizontal gradient
gradientY = zeros(rows, cols); % Vertical gradient
gradientMagnitude = zeros(rows, cols); % Gradient magnitude

% Pad the image with zeros to handle borders
paddedImage = padarray(inputImage, [1, 1], 0);

% Compute the gradients using the Sobel kernels
for i = 2:rows+1
    for j = 2:cols+1
        % Extract the 3x3 neighborhood
        region = paddedImage(i-1:i+1, j-1:j+1);
        
        % Apply the Sobel kernels
        gradientX(i-1, j-1) = sum(sum(region .* Gx));
        gradientY(i-1, j-1) = sum(sum(region .* Gy));
    end
end

% Calculate the gradient magnitude
gradientMagnitude = sqrt(gradientX.^2 + gradientY.^2);

% Normalize the gradient magnitude to range [0, 255]
gradientMagnitude = gradientMagnitude / max(gradientMagnitude(:)) * 255;

% Threshold the gradient magnitude to create a binary edge map
threshold = 50; % Adjust threshold as needed
edgeImage = gradientMagnitude > threshold;

% Display the results
figure;
subplot(1, 3, 1), imshow(uint8(inputImage)), title('Original Image');
subplot(1, 3, 2), imshow(uint8(gradientMagnitude)), title('Gradient Magnitude');
subplot(1, 3, 3), imshow(edgeImage), title('Binary Edge Image');
