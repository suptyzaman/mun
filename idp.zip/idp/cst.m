% Load the image
img = imread('C:/Users/USER/Downloads/test/f.jpg');  % Replace with the name of your image file

% Convert the image to grayscale (if not already)
gray_img = rgb2gray(img);

% Get the minimum and maximum pixel values of the grayscale image
r_min = double(min(gray_img(:)));  % Minimum pixel value
r_max = double(max(gray_img(:)));  % Maximum pixel value

% Set the desired output range
s_min = 0;  % Minimum output pixel value
s_max = 255;  % Maximum output pixel value

% Apply contrast stretching
contrast_stretched_img = uint8((double(gray_img) - r_min) / (r_max - r_min) * (s_max - s_min) + s_min);

% Display the original and contrast stretched images
figure;
subplot(1, 2, 1);
imshow(gray_img);
title('Original Image');

subplot(1, 2, 2);
imshow(contrast_stretched_img);
title('Contrast Stretched Image');
