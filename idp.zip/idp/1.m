function regionSplittingMerging()
    % Read the input image
    inputImagee = imread('cameraman.tif'); % Replace 'image.jpg' with your image file name
    
    % Convert to grayscale if the image is RGB
    if size(inputImagee, 3) == 3
        inputImage = rgb2gray(inputImagee);
    end
    
    % Normalize the image to [0, 1]
    inputImage = double(inputImage) / 255;
    
    % Set the threshold for splitting
    threshold = 0.05;
    
    % Initialize the region segmentation
    segmentedRegions = zeros(size(inputImage));
    
    % Start with the whole image as the initial region
    initialRegion = [1, 1, size(inputImage, 1), size(inputImage, 2)];
    
    % Perform region splitting
    regions = splitRegion(inputImage, initialRegion, threshold);
    
    % Assign unique labels to merged regions
    for i = 1:numel(regions)
        region = regions{i};
        segmentedRegions(region(1):region(3), region(2):region(4)) = i;
    end
    
    % Display results
    figure;
    subplot(1, 2, 1), imshow(inputImagee), title('Original Image');
    subplot(1, 2, 2), imshow(label2rgb(segmentedRegions)), title('Segmented Regions');
end

function regions = splitRegion(image, region, threshold)
    % Recursive function to split a region if variance exceeds the threshold
    x1 = region(1); y1 = region(2);
    x2 = region(3); y2 = region(4);
    
    % Extract the region
    subRegion = image(x1:x2, y1:y2);
    
    % Calculate the variance of the region
    regionVariance = var(subRegion(:));
    
    % Check if the region needs splitting
    if regionVariance > threshold && (x2 - x1 > 1) && (y2 - y1 > 1)
        % Split into 4 subregions
        xm = floor((x1 + x2) / 2);
        ym = floor((y1 + y2) / 2);
        
        % Recursively split each subregion
        regions1 = splitRegion(image, [x1, y1, xm, ym], threshold);
        regions2 = splitRegion(image, [x1, ym + 1, xm, y2], threshold);
        regions3 = splitRegion(image, [xm + 1, y1, x2, ym], threshold);
        regions4 = splitRegion(image, [xm + 1, ym + 1, x2, y2], threshold);
        
        % Combine regions
        regions = [regions1, regions2, regions3, regions4];
    else
        % If no splitting is needed, return the current region
        regions = {region};
����end
end