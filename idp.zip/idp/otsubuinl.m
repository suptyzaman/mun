% Read the input image
gray_image = imread('C:/Users/USER/Downloads/gg.jpg');

% Convert to grayscale if it's a color image
if size(gray_image, 3) == 3
    gray_image = rgb2gray(gray_image);
end

% Apply OTSU thresholding
threshold = graythresh(gray_image);  % Calculate OTSU threshold
binary_image = imbinarize(gray_image, threshold);  % Binarize image

% Detect edges on the binary image using Sobel method
otsu_edges = edge(binary_image, 'sobel');

% Display results
subplot(1, 3, 1); imshow(gray_image); title('Original Grayscale Image');
subplot(1, 3, 2); imshow(binary_image); title('Binary Image (OTSU)');
subplot(1, 3, 3); imshow(otsu_edges); title('Edges Detected (OTSU + Sobel)');
