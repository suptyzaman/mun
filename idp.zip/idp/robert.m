% Edge Detection Using Roberts Cross Operator
% Read an input image
input_image = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace 'image.jpg' with your image file
input_image = rgb2gray(input_image); % Convert to grayscale if it's a color image
input_image = double(input_image); % Convert to double for calculations

% Define Roberts Cross Kernel
Gx = [1 0; 0 -1]; % Horizontal kernel
Gy = [0 1; -1 0]; % Vertical kernel

% Get the dimensions of the image
[rows, cols] = size(input_image);

% Initialize gradient matrices
gradient_x = zeros(rows, cols);
gradient_y = zeros(rows, cols);
gradient_magnitude = zeros(rows, cols);

% Apply the Roberts Cross kernels
for i = 1:rows-1 % Avoid boundary pixels
    for j = 1:cols-1
        % Compute gradients using the kernels
        gradient_x(i, j) = input_image(i, j) * Gx(1, 1) + input_image(i, j+1) * Gx(1, 2) + ...
                           input_image(i+1, j) * Gx(2, 1) + input_image(i+1, j+1) * Gx(2, 2);
        gradient_y(i, j) = input_image(i, j) * Gy(1, 1) + input_image(i, j+1) * Gy(1, 2) + ...
                           input_image(i+1, j) * Gy(2, 1) + input_image(i+1, j+1) * Gy(2, 2);
    end
end

% Compute the magnitude of the gradient
gradient_magnitude = sqrt(gradient_x.^2 + gradient_y.^2);

% Normalize the gradient magnitude for display
gradient_magnitude = uint8(255 * mat2gray(gradient_magnitude));

% Display the results
figure;
subplot(2, 1, 1); imshow(uint8(input_image)); title('Original Image');
subplot(2, 1, 2); imshow(gradient_magnitude); title('Edge Detection (Roberts)');

