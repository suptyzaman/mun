clc;
clear;
img=imread('cameraman.tif');

windowsize=15;

paddingtype='symmetric';

paddedImage=padarray(img,[floor(windowsize/2),floor(windowsize/2)],paddingtype);

[rows,cols]=size(img);

outputImage=zeros(rows,cols);

for i=1:rows-1
    for j=1:cols-1
        
        localwindow=paddedImage(i:i+windowsize-1,j:j+windowsize-1);
        localthrehold=mean(localwindow(:));
        if  img(i,j)>localthrehold
            outputImage(i,j)=1;
            
        end
        if img(i,j)<=localthrehold
            outputImage(i,j)=0;
        end
        
    end
end
 figure;
subplot(1, 2, 1);
imshow(img); % Display the original image
title('Original Image');

subplot(1, 2, 2);
imshow(outputImage);
title('local tnhrheshold��Image');