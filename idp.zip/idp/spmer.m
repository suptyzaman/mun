function region_splitting_and_merging()
    % Load the image
    image = imread('C:/Users/USER/Downloads/gg.jpg');
    if size(image, 3) == 3
        image = rgb2gray(image); % Convert to grayscale
    end

    % Set the threshold for homogeneity
    threshold = 20; % Adjust this value as needed

    % Perform region splitting
    segmented_image = recursive_split(image, threshold);

    % Save and display the segmented image
    imwrite(segmented_image, 'segmented_image.png');
    imshow(segmented_image, []);
    title('Segmented Image');
end

% Recursive function to perform region splitting
function segmented = recursive_split(region, threshold)
    [rows, cols] = size(region);

    % Base case: If region is too small, return zeros
    if rows <= 1 || cols <= 1
        segmented = zeros(size(region), 'uint8');
        return;
    end

    % Check if the region is homogeneous
    if max(region(:)) - min(region(:)) <= threshold
        % Assign a single region label (255 for visualization)
        segmented = 255 * ones(size(region), 'uint8');
        return;
    end

    % Split the region into four quadrants
    mid_row = floor(rows / 2);
    mid_col = floor(cols / 2);

    % Recursive calls for each quadrant
    segmented = zeros(size(region), 'uint8');
    segmented(1:mid_row, 1:mid_col) = recursive_split(region(1:mid_row, 1:mid_col), threshold);
    segmented(1:mid_row, mid_col+1:end) = recursive_split(region(1:mid_row, mid_col+1:end), threshold);
    segmented(mid_row+1:end, 1:mid_col) = recursive_split(region(mid_row+1:end, 1:mid_col), threshold);
    segmented(mid_row+1:end, mid_col+1:end) = recursive_split(region(mid_row+1:end, mid_col+1:end), threshold);
end