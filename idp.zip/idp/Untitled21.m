% Read the input image
input_image = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace with your image file

% Convert to grayscale if the image is in color
if size(input_image, 3) == 3
    input_image = rgb2gray(input_image);
end

% Manual computation of histogram
pixel_count = zeros(256, 1); % Initialize a vector to store counts of each intensity (0-255)

% Loop through each pixel and count the intensity values
[rows, cols] = size(input_image); % Get dimensions of the image
for i = 1:rows
    for j = 1:cols
        intensity = input_image(i, j); % Get the pixel intensity
        pixel_count(intensity + 1) = pixel_count(intensity + 1) + 1; % Increment the corresponding bin
    end
end

% Create a new figure for the results
figure;

% Display the original image
subplot(1, 2, 1);
imshow(input_image);
title('Original Image');

% Plot the manually computed histogram
subplot(1, 2, 2);
bar(0:255, pixel_count, 'BarWidth', 1, 'FaceColor', 'k'); % x-axis: intensity values (0-255)
xlabel('Intensity Values (0-255)');
ylabel('Frequency');
title('Manually Computed Histogram');
xlim([0 255]);
grid on;
