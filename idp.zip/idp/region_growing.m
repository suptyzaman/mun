% Read the input image
input_image = imread('C:/Users/USER/Downloads/gg.jpg');
if size(input_image, 3) == 3
    input_image = rgb2gray(input_image);
end

% Convert the image to double for processing
input_image = double(input_image);

% Get the seed point (user input)
figure, imshow(uint8(input_image)), title('Select a Seed Point');
[x, y] = ginput(1);
x = round(x); y = round(y);

% Define parameters
seed_value = input_image(y, x);
threshold = 10; % Intensity similarity threshold
segmented_image = zeros(size(input_image));
visited = false(size(input_image));
queue = [y, x]; % Initialize the queue with the seed point

% Region growing algorithm
while ~isempty(queue)
    % Get the first pixel in the queue
    current_pixel = queue(1, :);
    queue(1, :) = [];
    row = current_pixel(1);
    col = current_pixel(2);
    
    % Skip if already visited
    if visited(row, col)
        continue;
    end
    
    % Mark as visited
    visited(row, col) = true;
    
    % Check intensity similarity
    if abs(input_image(row, col) - seed_value) <= threshold
        segmented_image(row, col) = 1; % Add to the region
        
        % Add neighboring pixels to the queue
        for i = -1:1
            for j = -1:1
                if i == 0 && j == 0
                    continue;
                end
                new_row = row + i;
                new_col = col + j;
                if new_row > 0 && new_row <= size(input_image, 1) && ...
                   new_col > 0 && new_col <= size(input_image, 2) && ...
                   ~visited(new_row, new_col)
                    queue = [queue; new_row, new_col]; %#ok<AGROW>
                end
            end
        end
    end
end

% Display results
segmented_image = uint8(segmented_image * 255);
figure;
subplot(1, 2, 1), imshow(uint8(input_image)), title('Original Image');
subplot(1, 2, 2), imshow(segmented_image), title('Segmented Region');
