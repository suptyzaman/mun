% MATLAB Program for Region Growing Algorithm
clc;
clear;
close all;

% Read the input image
input_image = imread('cameraman.tif'); % Replace with your image path
%if size(input_image, 3) == 3
    %input_image = rgb2gray(input_image); % Convert to grayscale
%end

% Display the original image
figure;
subplot(2,1,1);
imshow(input_image);
title('Original Image');

% Initialize parameters for region growing
seed_point = [100, 100]; % Seed point (row, column) - manually chosen
threshold = 20;          % Intensity difference threshold
region = zeros(size(input_image)); % Initialize region
visited = false(size(input_image)); % Keep track of visited pixels

% Initialize region growing
[row, col] = size(input_image);
stack = [seed_point]; % Initialize stack with the seed point
seed_intensity = input_image(seed_point(1), seed_point(2));

while ~isempty(stack)
    % Pop the top pixel
    current_pixel = stack(end, :);
    stack(end, :) = [];
    x = current_pixel(1);
    y = current_pixel(2);
    
    if ~visited(x, y)
        % Mark the pixel as visited
        visited(x, y) = true;
        
        % Add the pixel to the region if it meets the similarity condition
        if abs(input_image(x, y) - seed_intensity) <= threshold
            region(x, y) = 1;
            
            % Add 4-connected neighbors to the stack
            if x > 1, stack = [stack; x-1, y]; end
            if x < row, stack = [stack; x+1, y]; end
            if y > 1, stack = [stack; x, y-1]; end
            if y < col, stack = [stack; x, y+1]; end
        end
    end
end

% Display the segmented region
subplot(2,1,2);
imshow(region);
title('Segmented�Region');