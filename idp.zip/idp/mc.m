function mc()
    % Main script
    % Read the input image and convert it to grayscale
    image = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace with your image path
    if size(image, 3) == 3
        image = rgb2gray(image);
    end
    image = double(image);

    % Robert Operator
    roberts_x = [1 0; 0 -1];
    roberts_y = [0 1; -1 0];
    roberts_edge_x = manual_convolution(image, roberts_x);
    roberts_edge_y = manual_convolution(image, roberts_y);
    roberts_edge = sqrt(roberts_edge_x.^2 + roberts_edge_y.^2);

    % Prewitt Operator
    prewitt_x = [-1 0 1; -1 0 1; -1 0 1];
    prewitt_y = [-1 -1 -1; 0 0 0; 1 1 1];
    prewitt_edge_x = manual_convolution(image, prewitt_x);
    prewitt_edge_y = manual_convolution(image, prewitt_y);
    prewitt_edge = sqrt(prewitt_edge_x.^2 + prewitt_edge_y.^2);

    % Sobel Operator
    sobel_x = [-1 0 1; -2 0 2; -1 0 1];
    sobel_y = [-1 -2 -1; 0 0 0; 1 2 1];
    sobel_edge_x = manual_convolution(image, sobel_x);
    sobel_edge_y = manual_convolution(image, sobel_y);
    sobel_edge = sqrt(sobel_edge_x.^2 + sobel_edge_y.^2);

    % Display results
    figure;
    subplot(2, 2, 1);
    imshow(uint8(image));
    title('Original Image');

    subplot(2, 2, 2);
    imshow(uint8(roberts_edge));
    title('Robert Operator');

    subplot(2, 2, 3);
    imshow(uint8(prewitt_edge));
    title('Prewitt Operator');

    subplot(2, 2, 4);
    imshow(uint8(sobel_edge));
    title('Sobel Operator');
end

% Function definitions must go here
function result = manual_convolution(image, kernel)
    [img_h, img_w] = size(image);
    [k_h, k_w] = size(kernel);
    pad_h = floor(k_h / 2);
    pad_w = floor(k_w / 2);
    
    % Pad the image
    padded_image = padarray(image, [pad_h, pad_w]);
    
    % Initialize result matrix
    result = zeros(img_h, img_w);
    
    % Perform convolution
    for i = 1:img_h
        for j = 1:img_w
            region = padded_image(i:i+k_h-1, j:j+k_w-1);
            result(i, j) = sum(sum(region .* kernel));
        end
    end
end
