img1 = imread('C:/Users/USER/Downloads/test/ss.jpg');


R = img1(:, :, 1); 
G = img1(:, :, 2); 
B = img1(:, :, 3); 


gray = 0.2989 * double(R) + 0.5870 * double(G) + 0.1140 * double(B);



subplot(2, 3, 1); 
imshow(img1);
title('RGB Image');


subplot(2, 3, 2);
imshow(uint8(gray));
title('Grayscale Image');

subplot(2, 3, 3);
imshow(R); 
title('Red Channel');
subplot(2, 3, 4);
imshow(G); 
title('green Channel');
subplot(2, 3, 5);
imshow(B); 
title('blue Channel');
