% Read the handwritten document image
img = imread('C:\Users\USER\Downloads\t.jpg');  % Replace with the path to your image

% Display the original image
figure;
imshow(img);
title('Original Handwritten Document');

% Convert the image to grayscale (if not already)
gray_img = rgb2gray(img);

% Binarize the image for better OCR performance
binary_img = imbinarize(gray_img);

% Display the binarized image
figure;
imshow(binary_img);
title('Binarized Image');

% Apply OCR to extract text
ocr_results = ocr(binary_img);

% Extract the recognized text
recognized_text = ocr_results.Text;

% Display the extracted text
disp('Extracted Text:');
disp(recognized_text);

% Save the extracted text to a file
fileID = fopen('extracted_text.txt', 'w');
fprintf(fileID, '%s', recognized_text);
fclose(fileID);

disp('Extracted text has been saved to "extracted_text.txt".');