% Load the RGB image
img = imread('C:/Users/USER/Downloads/test/ss.jpg');  % Replace with your image file name

% Separate the RGB channels
R = img(:, :, 1);  % Red channel
G = img(:, :, 2);  % Green channel
B = img(:, :, 3);  % Blue channel

% Convert RGB to grayscale using weighted sum
grayscale_img = 0.2989 * double(R) + 0.5870 * double(G) + 0.1140 * double(B);
grayscale_img = uint8(grayscale_img);  % Convert to uint8 for display

% Convert grayscale back to RGB by replicating grayscale values in each channel
%reconstructed_R = grayscale_img;
%reconstructed_G = grayscale_img;
%reconstructed_B = grayscale_img;
%reconstructed_RGB = cat(3, reconstructed_R, reconstructed_G, reconstructed_B);

% Reconstruct RGB image from the grayscale image
reconstructed_R = grayImage; % Red channel
reconstructed_G = grayImage; % Green channel
reconstructed_B = grayImage; % Blue channel

reconstructed_RGB = zeros(rows, cols, 3, 'uint8'); % Initialize reconstructed RGB image
for i = 1:rows
    for j = 1:cols
        reconstructed_RGB(i, j, 1) = reconstructed_R(i, j); % Red channel
        reconstructed_RGB(i, j, 2) = reconstructed_G(i, j); % Green channel
        reconstructed_RGB(i, j, 3) = reconstructed_B(i, j); % Blue channel
    end
end

% Display the original image, grayscale image, and color channels
figure;

% Display original RGB image
subplot(2, 3, 1); 
imshow(img); 
title('Original Image');

% Display grayscale image
subplot(2, 3, 2); 
imshow(grayscale_img, []); 
title('Grayscale Image'); 

% Display red channel
subplot(2, 3, 3); 
imshow(R); 
title('Red Channel'); 

% Display green channel
subplot(2, 3, 4); 
imshow(G); 
title('Green Channel'); 

% Display blue channel
subplot(2, 3, 5); 
imshow(B); 
title('Blue Channel');

% Display reconstructed RGB image
subplot(2, 3, 6); 
imshow(reconstructed_RGB);
title('Reconstructed RGB Image');
