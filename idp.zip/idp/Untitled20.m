clc;
clear;
close all;

% Read the input image
gray_image = imread('C:/Users/USER/Downloads/test/f.jpg');
if size(gray_image, 3) == 3
    gray_image = gray_image(:, :, 1); % Extract one channel if it's an RGB image
end
gray_image = double(gray_image); % Convert to double for calculations

% Smoothing using a Gaussian filter (manual implementation)
% Define Gaussian kernel
sigma = 2;
kernel_size = 5; % Kernel size (odd number)
half_size = floor(kernel_size / 2);

[x, y] = meshgrid(-half_size:half_size, -half_size:half_size);
gaussian_kernel = exp(-(x.^2 + y.^2) / (2 * sigma^2));
gaussian_kernel = gaussian_kernel / sum(gaussian_kernel(:)); % Normalize the kernel

% Apply Gaussian filter manually
[M, N] = size(gray_image);
padded_image = padarray(gray_image, [half_size, half_size], 'replicate'); % Add padding
smoothed_image = zeros(M, N);

for i = 1:M
    for j = 1:N
        region = padded_image(i:i+kernel_size-1, j:j+kernel_size-1);
        smoothed_image(i, j) = sum(region(:) .* gaussian_kernel(:));
    end
end

% Sharpening using unsharp masking (manual implementation)
% Define sharpening mask
sharpening_factor = 1.5;
high_pass_filter = gray_image - smoothed_image; % High-pass filter (details)
sharpened_image = gray_image + sharpening_factor * high_pass_filter; % Add details back
sharpened_image = max(0, min(255, sharpened_image)); % Clip values to valid range

% Convert images back to uint8 for display
gray_image = uint8(gray_image);
smoothed_image = uint8(smoothed_image);
sharpened_image = uint8(sharpened_image);

% Display results
figure;
subplot(1, 3, 1); imshow(gray_image); title('Original Image');
subplot(1, 3, 2); imshow(smoothed_image); title('Smoothed Image');
subplot(1, 3, 3); imshow(sharpened_image); title('Sharpened Image');
