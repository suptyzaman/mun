% Load the RGB image
image = imread('C:/Users/USER/Downloads/test/ss.jpg'); % Replace with your image path

% Extract the Red, Green, and Blue channels manually
[rows, cols, ~] = size(image); % Get the dimensions of the image
R = zeros(rows, cols); % Initialize Red channel matrix
G = zeros(rows, cols); % Initialize Green channel matrix
B = zeros(rows, cols); % Initialize Blue channel matrix

for i = 1:rows
    for j = 1:cols
        R(i, j) = image(i, j, 1); % Extract Red
        G(i, j) = image(i, j, 2); % Extract Green
        B(i, j) = image(i, j, 3); % Extract Blue
    end
end

% Convert RGB to grayscale using the weighted formula
grayImage = zeros(rows, cols); % Initialize grayscale image
for i = 1:rows
    for j = 1:cols
        grayImage(i, j) = 0.2989 * R(i, j) + 0.5870 * G(i, j) + 0.1140 * B(i, j);
    end
end
grayImage = uint8(grayImage); % Convert to uint8

% Reconstruct RGB image from the grayscale image
reconstructed_R = grayImage; % Red channel
reconstructed_G = grayImage; % Green channel
reconstructed_B = grayImage; % Blue channel

reconstructed_RGB = zeros(rows, cols, 3, 'uint8'); % Initialize reconstructed RGB image
for i = 1:rows
    for j = 1:cols
        reconstructed_RGB(i, j, 1) = reconstructed_R(i, j); % Red channel
        reconstructed_RGB(i, j, 2) = reconstructed_G(i, j); % Green channel
        reconstructed_RGB(i, j, 3) = reconstructed_B(i, j); % Blue channel
    end
end

% Display the results
figure;

% Display original RGB image
subplot(2, 3, 1);
imshow(image);
title('Original RGB Image');

% Display red channel
subplot(2, 3, 2);
imshow(uint8(R));
title('Red Channel');

% Display green channel
subplot(2, 3, 3);
imshow(uint8(G));
title('Green Channel');

% Display blue channel
subplot(2, 3, 4);
imshow(uint8(B));
title('Blue Channel');

% Display grayscale image
subplot(2, 3, 5);
imshow(grayImage);
title('Grayscale Image');

% Display reconstructed RGB image
subplot(2, 3, 6);
imshow(reconstructed_RGB);
title('Reconstructed RGB Image');
