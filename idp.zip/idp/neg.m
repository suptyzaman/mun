img1 = imread('C:/Users/USER/Downloads/test/f.jpg');


R = img1(:, :, 1); 
G = img1(:, :, 2); 
B = img1(:, :, 3); 


%gray = 0.2989 * double(R) + 0.5870 * double(G) + 0.1140 * double(B);


L = 256; 
negativeImg = L - 1 - img1;
subplot(2, 3, 1); 
imshow(negativeImg);
title('negativeImage');
subplot(2, 3, 2); 
imshow(img1);
title('RGB Image');