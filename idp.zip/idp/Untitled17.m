clc;
clear;
close all;

% Load the input image
img = imread('C:/Users/USER/Downloads/cm.jpg'); % Replace with your image path

% Convert the image to grayscale (if not already)
if size(img, 3) == 3
    gray_img = rgb2gray(img);
else
    gray_img = img;
end

% Display the original image
figure;
subplot(1, 3, 1);
imshow(gray_img);
title('Original Grayscale Image');

%% Global Thresholding
% Set a global threshold value (e.g., 128 for an 8-bit image)
global_thresh = 128;
global_binary_img = gray_img > global_thresh; % Convert to binary using the threshold

% Display the result of global thresholding
subplot(1, 3, 2);
imshow(global_binary_img);
title('Global Thresholding');

%% Manual Otsu's Thresholding
% Step 1: Compute histogram and probabilities
counts = imhist(gray_img); % Histogram of the grayscale image
total_pixels = numel(gray_img); % Total number of pixels
probabilities = counts / total_pixels; % Normalize histogram to get probabilities

% Step 2: Initialize variables for Otsu's method
max_variance = 0; % Maximum between-class variance
optimal_threshold = 0; % Best threshold

% Step 3: Iterate through all possible thresholds
for t = 1:256
    % Class 1 (background): [0, t-1]
    w1 = sum(probabilities(1:t)); % Weight of class 1
    mu1 = sum((0:t-1)' .* probabilities(1:t)) / w1; % Mean of class 1

    % Class 2 (foreground): [t, 255]
    w2 = sum(probabilities(t+1:end)); % Weight of class 2
    mu2 = sum((t:255)' .* probabilities(t+1:end)) / w2; % Mean of class 2

    % Between-class variance
    variance_between = w1 * w2 * (mu1 - mu2)^2;

    % Update optimal threshold if variance is maximum
    if variance_between > max_variance
        max_variance = variance_between;
        optimal_threshold = t - 1; % Adjust for MATLAB indexing
    end
end

% Step 4: Apply the optimal threshold
manual_otsu_binary_img = gray_img > optimal_threshold;

% Display the result of Otsu's thresholding
subplot(1, 3, 3);
imshow(manual_otsu_binary_img);
title('Manual Otsu Thresholding');

% Display the computed threshold values
fprintf('Global Threshold Value: %.4f\n', global_thresh / 255);
fprintf('Otsu Threshold Value (Manual): %.4f\n', optimal_threshold / 255);