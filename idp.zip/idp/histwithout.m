clc;
clear;
close all;

% Read the input image
input_image = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace 'your_image.jpg' with the actual image file

% Convert to grayscale if the image is in color
if size(input_image, 3) == 3
    input_image = rgb2gray(input_image); % Convert the RGB image to grayscale
end

% Convert image to a double type for accurate calculations
input_image = double(input_image);

% Compute the histogram manually (no built-in function)
% Initialize a zero vector to hold pixel counts for each intensity level
pixel_count = zeros(1, 256);

% Loop through each pixel in the image and update the pixel_count array
for i = 1:size(input_image, 1) % Loop through rows
    for j = 1:size(input_image, 2) % Loop through columns
        intensity = round(input_image(i, j)); % Get the intensity value of the pixel
        pixel_count(intensity + 1) = pixel_count(intensity + 1) + 1; % Increment the count for this intensity level
    end
end

% Create a new figure for displaying the original image and its histogram
figure;
subplot(1, 2, 1);
imshow(uint8(input_image)); % Convert back to uint8 for displaying the image
title('Original Image');

% Plot the histogram of the image
subplot(1, 2, 2);
bar(pixel_count, 'BarWidth', 1, 'FaceColor', 'k'); % Plot the histogram using the pixel counts
xlabel('Intensity Values (0-255)');
ylabel('Frequency');
title('Histogram of the Image');
xlim([0 255]); % Set x-axis limits to cover all intensity values
grid on; % Add a grid for better visibility
