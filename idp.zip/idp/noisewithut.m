clc;
clear;
close all;

% Load the image
image = imread('C:/Users/USER/Downloads/gg.jpg');

% Convert to grayscale if necessary
if size(image, 3) == 3
    image = rgb2gray(image);
end

% Image dimensions
[M, N] = size(image);

% Add Gaussian noise manually
mean = 0;
variance = 0.01;
gaussianNoise = uint8(sqrt(variance) * randn(M, N) + mean);
noisyGaussian = uint8(double(image) + double(gaussianNoise));

% Add salt-and-pepper noise manually
prob = 0.02; % Probability of noise
noisySaltPepper = image;
num_noise_pixels = floor(prob * M * N);
for i = 1:num_noise_pixels
    x = randi([1, M]);
    y = randi([1, N]);
    if rand < 0.5
        noisySaltPepper(x, y) = 0; % Salt (black pixel)
    else
        noisySaltPepper(x, y) = 255; % Pepper (white pixel)
    end
end

% Apply median filter manually
medianFiltered = noisySaltPepper;
windowSize = 3;
padding = floor(windowSize / 2);
paddedImage = padarray(noisySaltPepper, [padding, padding], 'replicate');
for i = 1:M
    for j = 1:N
        window = paddedImage(i:i+2*padding, j:j+2*padding);
        medianFiltered(i, j) = median(window(:));
    end
end

% Apply Gaussian filter manually
gaussianKernel = [1, 2, 1; 2, 4, 2; 1, 2, 1] / 16; % 3x3 Gaussian kernel
gaussianFiltered = zeros(M, N);
for i = 2:M-1
    for j = 2:N-1
        region = double(noisyGaussian(i-1:i+1, j-1:j+1));
        gaussianFiltered(i, j) = sum(sum(region .* gaussianKernel));
    end
end
gaussianFiltered = uint8(gaussianFiltered);

% Apply Wiener filter manually (5x5 window)
wienerFilteredGaussian = zeros(M, N, 'double');
wienerFilteredSaltPepper = zeros(M, N, 'double');
windowSize = 5;
padding = floor(windowSize / 2);
paddedGaussian = padarray(double(noisyGaussian), [padding, padding], 'replicate');
paddedSaltPepper = padarray(double(noisySaltPepper), [padding, padding], 'replicate');

for i = 1:M
    for j = 1:N
        % Wiener filter for Gaussian noise
        window = paddedGaussian(i:i+2*padding, j:j+2*padding);
        localMean = mean(window(:));
        localVariance = var(window(:));
        globalVariance = variance; % Assumed noise variance
        if localVariance > 0
            wienerFilteredGaussian(i, j) = ...
                double(noisyGaussian(i, j)) - (globalVariance / localVariance) * (double(noisyGaussian(i, j)) - localMean);
        else
            wienerFilteredGaussian(i, j) = double(noisyGaussian(i, j));
        end

        % Wiener filter for Salt-and-Pepper noise
        window = paddedSaltPepper(i:i+2*padding, j:j+2*padding);
        localMean = mean(window(:));
        localVariance = var(window(:));
        if localVariance > 0
            wienerFilteredSaltPepper(i, j) = ...
                double(noisySaltPepper(i, j)) - (globalVariance / localVariance) * (double(noisySaltPepper(i, j)) - localMean);
        else
            wienerFilteredSaltPepper(i, j) = double(noisySaltPepper(i, j));
        end
    end
end

wienerFilteredGaussian = uint8(wienerFilteredGaussian);
wienerFilteredSaltPepper = uint8(wienerFilteredSaltPepper);

% Display the results
figure;

subplot(3, 3, 1);
imshow(image);
title('Original Image');

subplot(3, 3, 2);
imshow(noisyGaussian);
title('Gaussian Noise');

subplot(3, 3, 3);
imshow(noisySaltPepper);
title('Salt-and-Pepper Noise');

subplot(3, 3, 4);
imshow(medianFiltered);
title('Median Filtered');

subplot(3, 3, 5);
imshow(gaussianFiltered);
title('Gaussian Filtered');

subplot(3, 3, 6);
imshow(wienerFilteredGaussian);
title('Wiener (Gaussian Noise)');

subplot(3, 3, 7);
imshow(wienerFilteredSaltPepper);
title('Wiener (Salt-Pepper Noise)');
