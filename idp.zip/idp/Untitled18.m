% Clear workspace and close all figures
clear; clc; close all;

% Load and display the original image
originalImage = im2double(imread('C:/Users/USER/Downloads/cm.jpg')); % Use a sample grayscale image
figure;
subplot(2, 2, 1);
imshow(originalImage);
title('Original Image');

% Apply Gaussian and Salt & Pepper noise
noisyImage_gaussian = imnoise(originalImage, 'gaussian', 0, 0.01); % Gaussian noise
noisyImage_saltpepper = imnoise(originalImage, 'salt & pepper', 0.02); % Salt & Pepper noise

% Display noisy images
subplot(2, 2, 2);
imshow(noisyImage_gaussian);
title('Gaussian Noise');

subplot(2, 2, 3);
imshow(noisyImage_saltpepper);
title('Salt & Pepper Noise');

% Apply filters to restore images
% Gaussian Noise Restoration
restored_gaussian = imgaussfilt(noisyImage_gaussian, 2); % Gaussian filter

% Salt & Pepper Noise Restoration
restored_saltpepper = medfilt2(noisyImage_saltpepper, [3, 3]); % Median filter

% Display restored images
figure;
subplot(1, 2, 1);
imshow(restored_gaussian);
title('Restored Gaussian');

subplot(1, 2, 2);
imshow(restored_saltpepper);
title('Restored Salt & Pepper');

% Evaluate performance
psnr_gaussian = psnr(restored_gaussian, originalImage);
psnr_saltpepper = psnr(restored_saltpepper, originalImage);

ssim_gaussian = ssim(restored_gaussian, originalImage);
ssim_saltpepper = ssim(restored_saltpepper, originalImage);

% Display performance metrics
fprintf('PSNR and SSIM Comparison:\n');
fprintf('Gaussian Noise - PSNR: %.2f, SSIM: %.2f\n', psnr_gaussian, ssim_gaussian);
fprintf('Salt & Pepper Noise - PSNR: %.2f, SSIM: %.2f\n', psnr_saltpepper, ssim_saltpepper);