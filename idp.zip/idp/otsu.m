% Read the input image
inputImage = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace with your image file
inputImage = rgb2gray(inputImage);      % Convert to grayscale if it's a color image

% Convert the image to double for computations
inputImage = double(inputImage);

% Step 1: Compute Gradient Magnitude using Sobel Operator
% Define Sobel Kernels
Gx = [-1 0 1; -2 0 2; -1 0 1];
Gy = [-1 -2 -1; 0 0 0; 1 2 1];

% Initialize gradient matrices
[rows, cols] = size(inputImage);
gradientX = zeros(rows, cols);
gradientY = zeros(rows, cols);

% Apply Sobel Operator
for i = 2:rows-1
    for j = 2:cols-1
        region = inputImage(i-1:i+1, j-1:j+1);
        gradientX(i, j) = sum(sum(region .* Gx));
        gradientY(i, j) = sum(sum(region .* Gy));
    end
end

% Compute Gradient Magnitude
gradientMagnitude = sqrt(gradientX.^2 + gradientY.^2);

% Normalize gradient magnitude to 0-255
gradientMagnitude = gradientMagnitude / max(gradientMagnitude(:)) * 255;

% Step 2: Implement OTSU's Method for Thresholding
% Flatten the gradient magnitude image into a histogram
histogram = zeros(256, 1); % Initialize histogram for pixel values [0-255]

% Compute the histogram
for value = 0:255
    histogram(value + 1) = sum(gradientMagnitude(:) == value);
end

% Compute total weight and mean
totalPixels = sum(histogram);
totalMean = sum((0:255) .* histogram') / totalPixels;

% Initialize variables for OTSU
maxVariance = 0;
optimalThreshold = 0;

% Iterate through all possible thresholds
weightBackground = 0;
meanBackground = 0;

for threshold = 0:255
    weightBackground = weightBackground + histogram(threshold + 1);
    if weightBackground == 0
        continue;
    end
    weightForeground = totalPixels - weightBackground;
    if weightForeground == 0
        break;
    end

    meanBackground = meanBackground + threshold * histogram(threshold + 1);
    currentMeanBackground = meanBackground / weightBackground;
    currentMeanForeground = (totalMean - meanBackground) / weightForeground;

    % Compute Between-Class Variance
    betweenClassVariance = weightBackground * weightForeground * ...
        (currentMeanBackground - currentMeanForeground)^2;

    % Update maximum variance and optimal threshold
    if betweenClassVariance > maxVariance
        maxVariance = betweenClassVariance;
        optimalThreshold = threshold;
    end
end

% Step 3: Threshold the Gradient Magnitude
binaryEdgeImage = gradientMagnitude > optimalThreshold;

% Display the Results
figure;
subplot(1, 3, 1); imshow(uint8(inputImage)); title('Original Image');
subplot(1, 3, 2); imshow(uint8(gradientMagnitude)); title('Gradient Magnitude');
subplot(1, 3, 3); imshow(binaryEdgeImage); title('Edge Detected Image (OTSU)');
