function main_script_without_builtin
    clc;
    clear;
    close all;

    % Load an image
    image = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace with your image path
    if size(image, 3) == 3
        image = rgb2gray(image);
    end
    image = double(image); % Convert to double for calculations

    % Otsu's Thresholding (without graythresh)
    otsu_threshold = compute_otsu_threshold(image); % Custom implementation
    otsu_binary = image > otsu_threshold; % Apply threshold

    % Local Thresholding
    block_size = 15; % Define the size of the blocks for local thresholding
    local_binary = local_threshold_without_builtin(image, block_size);

    % Performance Comparison
    original_binary = global_threshold_without_builtin(image, 128); % Approximation of ground truth
    psnr_otsu = compute_psnr(otsu_binary, original_binary);
    psnr_local = compute_psnr(local_binary, original_binary);

    % Display Results
    figure;
    subplot(2, 2, 1);
    imshow(uint8(image));
    title('Original Grayscale Image');

    subplot(2, 2, 2);
    imshow(otsu_binary);
    title(sprintf('Otsu Thresholding (PSNR: %.2f)', psnr_otsu));

    subplot(2, 2, 3);
    imshow(local_binary);
    title(sprintf('Local Thresholding (PSNR: %.2f)', psnr_local));

    subplot(2, 2, 4);
    imshow(original_binary);
    title('Ground Truth (Approximated)');
end

% Compute Otsu's Threshold Without Built-in Functions
function threshold = compute_otsu_threshold(image)
    [counts, ~] = histogram_custom(image, 256); % Compute histogram
    total_pixels = sum(counts);
    probabilities = counts / total_pixels;

    max_variance = 0;
    threshold = 0;

    for t = 1:256
        % Class probabilities
        w0 = sum(probabilities(1:t)); % Background weight
        w1 = sum(probabilities(t+1:end)); % Foreground weight

        if w0 == 0 || w1 == 0
            continue; % Skip empty classes
        end

        % Class means
        mu0 = sum((0:t-1) .* probabilities(1:t)) / w0; % Background mean
        mu1 = sum((t:255) .* probabilities(t+1:end)) / w1; % Foreground mean

        % Between-class variance
        variance_between = w0 * w1 * (mu0 - mu1)^2;

        % Update threshold if variance is maximum
        if variance_between > max_variance
            max_variance = variance_between;
            threshold = t - 1; % Adjust for MATLAB indexing
        end
    end
end

% Perform Local Thresholding Without Built-in Functions
function local_binary = local_threshold_without_builtin(image, block_size)
    [rows, cols] = size(image);
    local_binary = zeros(rows, cols);
    half_block = floor(block_size / 2);

    % Padding the image manually
    padded_image = zeros(rows + 2 * half_block, cols + 2 * half_block);
    padded_image(half_block+1:end-half_block, half_block+1:end-half_block) = image;

    % Reflect padding
    padded_image(1:half_block, :) = padded_image(half_block+1:2*half_block, :);
    padded_image(end-half_block+1:end, :) = padded_image(end-2*half_block:end-half_block-1, :);
    padded_image(:, 1:half_block) = padded_image(:, half_block+1:2*half_block);
    padded_image(:, end-half_block+1:end) = padded_image(:, end-2*half_block:end-half_block-1);

    % Apply local thresholding
    for i = 1:rows
        for j = 1:cols
            local_region = padded_image(i:i+block_size-1, j:j+block_size-1);
            local_thresh = mean(local_region(:)); % Local mean threshold
            local_binary(i, j) = image(i, j) > local_thresh;
        end
    end
end

% Compute Global Threshold Without Built-in Functions
function binary_image = global_threshold_without_builtin(image, threshold)
    binary_image = image > threshold; % Apply a fixed global threshold
end

% Compute Histogram Without Built-in Functions
function [counts, bins] = histogram_custom(image, num_bins)
    bins = linspace(0, 255, num_bins);
    counts = zeros(1, num_bins);

    for i = 1:numel(image)
        bin_idx = floor(image(i) * (num_bins - 1) / 255) + 1;
        counts(bin_idx) = counts(bin_idx) + 1;
    end
end

% Compute PSNR Without Built-in Functions
function psnr_value = compute_psnr(image1, image2)
    mse = mean((image1(:) - image2(:)).^2); % Mean squared error
    if mse == 0
        psnr_value = Inf; % If images are identical
    else
        max_intensity = max(image1(:));
        psnr_value = 10 * log10(max_intensity^2 / mse);
    end
end
