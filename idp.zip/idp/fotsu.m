% Otsu Edge Detection in MATLAB Without Built-in Functions
% Read the input image
inputImage = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace 'image.jpg' with your image file
if size(inputImage, 3) == 3
    inputImage = rgb2gray(inputImage); % Convert to grayscale if the image is RGB
end

% Convert the image to a normalized grayscale (0-1)
inputImage = double(inputImage) / 255;

% Calculate the histogram of the image
histogram = zeros(1, 256);
for i = 1:numel(inputImage)
    intensity = round(inputImage(i) * 255);
    histogram(intensity + 1) = histogram(intensity + 1) + 1;
end

% Normalize the histogram
totalPixels = numel(inputImage);
histogram = histogram / totalPixels;

% Calculate Otsu's threshold
maxVariance = 0;
threshold = 0;
for t = 1:256
    % Split the histogram into two groups
    q1 = sum(histogram(1:t)); % Weight of class 1
    q2 = sum(histogram(t+1:end)); % Weight of class 2
    
    if q1 == 0 || q2 == 0
        continue;
    end
    
    % Means of the two groups
    mu1 = sum((0:t-1) .* histogram(1:t)) / q1;
    mu2 = sum((t:255) .* histogram(t+1:end)) / q2;
    
    % Between-class variance
    varianceBetween = q1 * q2 * (mu1 - mu2)^2;
    
    % Update the maximum variance and threshold
    if varianceBetween > maxVariance
        maxVariance = varianceBetween;
        threshold = t - 1;
    end
end

% Apply the threshold
binaryImage = inputImage > (threshold / 255);

% Edge detection using the binary image
edgeImage = edge(binaryImage, 'sobel'); % Optionally, implement your own Sobel filter

% Display the results
figure;
subplot(1, 3, 1), imshow(inputImage, []), title('Original Image');
subplot(1, 3, 2), imshow(binaryImage, []), title('Binary Image (Otsu Threshold)');
subplot(1, 3, 3), imshow(edgeImage, []), title('Edge Detected Image');
