% Clear workspace and command window
clc;
clear;
close all;

% Load a grayscale or RGB image
img = imread('C:/Users/USER/Downloads/cm.jpg'); % Replace with your image file path

% Convert to grayscale if the image is RGB
if size(img, 3) == 3
    gray_img = rgb2gray(img); % Convert RGB to grayscale
else
    gray_img = img; % Use directly if already grayscale
end

% Global thresholding
global_threshold = 128; % Set global threshold (can be adjusted)
binary_global = gray_img >= global_threshold; % Apply global thresholding

% Otsu's thresholding
otsu_threshold = graythresh(gray_img) * 255; % Calculate Otsu's threshold (scaled to 0-255)
binary_otsu = gray_img >= otsu_threshold; % Apply Otsu's thresholding

% Display results
figure;

% Original grayscale image
subplot(2, 3, 1);
imshow(gray_img);
title('Original Grayscale Image');

% Global thresholding result
subplot(2, 3, 2);
imshow(binary_global);
title(['Global Thresholding (T = ', num2str(global_threshold), ')']);

% Otsu's thresholding result
subplot(2, 3, 3);
imshow(binary_otsu);
title(['Otsu Thresholding (T = ', num2str(round(otsu_threshold)), ')']);

% Histogram of original image
subplot(2, 3, 4);
imhist(gray_img);
title('Histogram of Grayscale Image');
xlabel('Pixel Intensity');
ylabel('Frequency');

% Mark global threshold on histogram
hold on;
xline(global_threshold, 'r', 'LineWidth', 1.5, 'Label', 'Global T');

% Mark Otsu's threshold on histogram
xline(otsu_threshold, 'g', 'LineWidth', 1.5, 'Label', 'Otsu T');
hold off;

% Comparison of binary results
subplot(2, 3, 5);
imshowpair(binary_global, binary_otsu, 'montage');
title('Global (Left) vs Otsu (Right) Thresholding');

% Summary
subplot(2, 3, 6);
text(0.1, 0.5, ...
    sprintf(['Global Threshold: %d\nOtsu Threshold: %.2f\n\n', ...
    'Global thresholding is fixed and less adaptive.\n', ...
    'Otsu thresholding is dynamic and adapts to histogram.']), ...
    'FontSize', 12);
axis off;

