clc;
clear;
close all;

% Load an image
image = imread('C:/Users/USER/Downloads/gg.jpg'); % Replace with your image path
if size(image, 3) == 3
    image = rgb2gray(image);
end
image = double(image); % Convert to double for calculations

% Otsu's Thresholding
otsu_threshold = graythresh(uint8(image)); % Compute the threshold (normalized to [0,1])
otsu_binary = image > (otsu_threshold * 255); % Apply threshold

% Local Thresholding
block_size = 15; % Define the size of the blocks for local thresholding
local_binary = local_threshold(image, block_size);

% Performance Comparison (Using PSNR)
original_binary = imbinarize(uint8(image)); % Ground truth approximation
psnr_otsu = psnr(double(otsu_binary), double(original_binary));
psnr_local = psnr(double(local_binary), double(original_binary));

% Display Results
figure;
subplot(2, 2, 1);
imshow(uint8(image));
title('Original Grayscale Image');

subplot(2, 2, 2);
imshow(otsu_binary);
title(sprintf('Otsu Thresholding (PSNR: %.2f)', psnr_otsu));

subplot(2, 2, 3);
imshow(local_binary);
title(sprintf('Local Thresholding (PSNR: %.2f)', psnr_local));

subplot(2, 2, 4);
imshow(original_binary);
title('Ground Truth (Approximated)');

% Function Definitions
function local_binary = local_threshold(image, block_size)
    % Perform local thresholding with a specified block size
    [rows, cols] = size(image);
    local_binary = zeros(rows, cols);
    
    half_block = floor(block_size / 2);
    padded_image = padarray(image, [half_block, half_block], 'symmetric');
    
    for i = 1:rows
        for j = 1:cols
            % Extract the local region
            local_region = padded_image(i:i+block_size-1, j:j+block_size-1);
            local_thresh = mean(local_region(:)); % Local mean threshold
            local_binary(i, j) = image(i, j) > local_thresh;
        end
    end
end
