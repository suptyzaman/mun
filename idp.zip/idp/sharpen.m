% Smoothing and sharpening

% Read the input image
gray_image = imread('C:/Users/USER/Downloads/test/f.jpg');
if size(gray_image, 3) == 3
    gray_image = rgb2gray(gray_image);
end

% Smoothing using a Gaussian filter
smoothed_image = imgaussfilt(gray_image, 2);

% Sharpening using an unsharp mask
sharpened_image = imsharpen(gray_image);

% Display results
subplot(1, 3, 1); imshow(gray_image); title('Original Image');
subplot(1, 3, 2); imshow(smoothed_image); title('Smoothed Image');
subplot(1, 3, 3); imshow(sharpened_image); title('Sharpened Image');