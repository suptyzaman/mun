function global_vs_otsu_thresholding()
    clc;
    clear;
    close all;

    % Load an image
    image = imread('C:/Users/USER/Downloads/cm.jpg'); % Replace with your image path
    if size(image, 3) == 3
        image = rgb2gray(image); % Convert to grayscale if the image is RGB
    end

    % Normalize image
    image = double(image);

    % Global Thresholding
    global_threshold = 128; % Example fixed threshold for 8-bit images
    global_binary = image > global_threshold;

    % Otsu's Thresholding
    otsu_threshold = graythresh(uint8(image)) * 255; % Compute Otsu's threshold
    otsu_binary = image > otsu_threshold;

    % Performance Evaluation
    % Use a ground truth approximation (binarized using a dynamic approach)
    ground_truth = imbinarize(uint8(image), graythresh(uint8(image)));

    psnr_global = psnr(double(global_binary), double(ground_truth));
    psnr_otsu = psnr(double(otsu_binary), double(ground_truth));

    % Display results
    figure;
    subplot(2, 2, 1);
    imshow(uint8(image));
    title('Original Grayscale Image');

    subplot(2, 2, 2);
    imshow(global_binary);
    title(sprintf('Global Thresholding (Threshold: %d, PSNR: %.2f)', ...
        global_threshold, psnr_global));

    subplot(2, 2, 3);
    imshow(otsu_binary);
    title(sprintf('Otsu Thresholding (Threshold: %.2f, PSNR: %.2f)', ...
        otsu_threshold, psnr_otsu));

    subplot(2, 2, 4);
    imshow(ground_truth);
    title('Ground Truth (Approximation)');
end
