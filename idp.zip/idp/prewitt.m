% Edge Detection Using Prewitt Operator
% Read an input image
input_image = imread('C:/Users/USER/Downloads/gg.jpg'); % Pic.pngReplace 'image.jpg' with your image file
input_image = rgb2gray(input_image); % Convert to grayscale if it's a color image
input_image = double(input_image); % Convert to double for calculations

% Define Prewitt Kernels
Gx = [-1 0 1; -1 0 1; -1 0 1]; % Horizontal kernel
Gy = [-1 -1 -1; 0 0 0; 1 1 1]; % Vertical kernel

% Get the dimensions of the image
[rows, cols] = size(input_image);

% Initialize gradient matrices
gradient_x = zeros(rows, cols);
gradient_y = zeros(rows, cols);
gradient_magnitude = zeros(rows, cols);

% Apply the Prewitt kernels
for i = 2:rows-1 % Avoid boundary pixels
    for j = 2:cols-1
        % Extract the 3x3 region around the current pixel
        region = input_image(i-1:i+1, j-1:j+1);
        
        % Compute gradients using the kernels
        gradient_x(i, j) = sum(sum(region .* Gx));
        gradient_y(i, j) = sum(sum(region .* Gy));
    end
end

% Compute the magnitude of the gradient
gradient_magnitude = sqrt(gradient_x.^2 + gradient_y.^2);

% Normalize the gradient magnitude for display
gradient_magnitude = uint8(255 * mat2gray(gradient_magnitude));

% Display the results
figure;
subplot(2, 1, 1); imshow(uint8(input_image)); title('Original Image');
subplot(2, 1, 2); imshow(gradient_magnitude); title('Edge Detection (Prewitt)');

