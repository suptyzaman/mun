% Read the image
img = imread('C:/Users/USER/Downloads/gg.jpg');

% Convert to grayscale
gray_img = 0.2989 * img(:, :, 1) + 0.5870 * img(:, :, 2) + 0.1140 * img(:, :, 3);

% Apply global thresholding
threshold = max(gray_img(:)) * 0.9; % Adjust threshold multiplier if needed
binary_mask = gray_img > threshold;

% Invert the binary mask
binary_mask = ~binary_mask;

% Remove background
binary_mask_repeated = repmat(binary_mask, [1, 1, 3]); % Repeat mask for RGB
background_removed = uint8(binary_mask_repeated) .* img;

% Display results
figure;
subplot(1, 3, 1), imshow(img), title('Original Image');
subplot(1, 3, 2), imshow(binary_mask), title('Binary Mask');
subplot(1, 3, 3), imshow(background_removed), title('Background Removed');
