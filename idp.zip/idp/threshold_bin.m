clc;
clear;
close all;

% Load a grayscale or RGB image
img = imread('C:/Users/USER/Downloads/test/f.jpg');

% Convert to grayscale if the image is RGB
if size(img, 3) == 3
    gray_img = rgb2gray(img); % Convert RGB to Grayscale
else
    gray_img = img; % Use directly if already grayscale
end

% Display the grayscale image
subplot(1, 3, 1);
imshow(gray_img);
title('Grayscale Image');

% Define a threshold value (0-255)
threshold = 128; % Adjust as needed

% Generate the binary image
binary_img = gray_img >= threshold;

% Display the binary image
subplot(1, 3, 2);
imshow(binary_img);
title(['Binary Image (Threshold = ', num2str(threshold), ')']);

% Display the original image for comparison
subplot(1, 3, 3);
imshow(img);
title('Original Image');
