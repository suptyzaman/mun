% Load and display the original and negative RGB images
rgbImage = imread('F:\MATLAB_DIP\labgray.jpg');    
negativeRgbImage = rgbNegative(rgbImage);

% Display the original and negative images
figure;
subplot(1, 2, 1); imshow(rgbImage); title('Original RGB');
subplot(1, 2, 2); imshow(negativeRgbImage); title('Negative RGB');

% Define the function for RGB image negative
function negativeImage = rgbNegative(rgbImage)
    % Get the dimensions of the RGB image
    [rows, cols, ~] = size(rgbImage);
    
    % Initialize an empty matrix for the negative image
    negativeImage = zeros(rows, cols,2);
    
    % Loop through each pixel and each color channel
    for i = 1:rows
        for j = 1:cols
            % Invert the red, green, and blue channels
            negativeImage(i, j, 1) = 255 - rgbImage(i, j, 1); % Red channel
            negativeImage(i, j, 2) = 255 - rgbImage(i, j, 2); % Green channel
            negativeImage(i, j, 3) = 255 - rgbImage(i, j, 3); % Blue channel
             
         
            
        end
    end
    
    % Convert to uint8 format for display purposes
    negativeImage = uint8(negativeImage);
end

