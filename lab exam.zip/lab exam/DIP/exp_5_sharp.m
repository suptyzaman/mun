function main()
    % Load an example grayscale image
    image = imread('F:\MATLAB_DIP\labgray.jpg'); % Replace with path to your image
    if size(image, 3) == 3
        image = rgb_to_grayscale(image); % Convert to grayscale if it's an RGB image
    end

    % Apply smoothing
    smoothed_image = smooth_image(image);

    % Apply sharpening
    sharpened_image = sharpen_image(image);

    % Display original, smoothed, and sharpened images
    figure;
    subplot(1, 3, 1);
    imshow(image);
    title('Original Image');

    subplot(1, 3, 2);
    imshow(smoothed_image);
    title('Smoothed Image');

    subplot(1, 3, 3);
    imshow(sharpened_image);
    title('Sharpened Image');
end

function grayscale_image = rgb_to_grayscale(rgb_image)
    % Convert RGB image to grayscale without built-in function
    [height, width, ~] = size(rgb_image);
    grayscale_image = zeros(height, width, 'uint8');
    for i = 1:height
        for j = 1:width
            R = double(rgb_image(i, j, 1));
            G = double(rgb_image(i, j, 2));
            B = double(rgb_image(i, j, 3));
            grayscale_image(i, j) = uint8(0.2989 * R + 0.5870 * G + 0.1140 * B);
        end
    end
end

function smoothed_image = smooth_image(image)
    % Define a Gaussian kernel for smoothing (3x3)
    kernel = [1, 2, 1;
              2, 4, 2;
              1, 2, 1];
    kernel = kernel / sum(kernel(:)); % Normalize the kernel

    % Get image dimensions
    [height, width] = size(image);

    % Initialize output image
    smoothed_image = zeros(height, width, 'uint8');

    % Apply convolution without using built-in function
    for i = 2:height-1
        for j = 2:width-1
            % Extract 3x3 region
            region = double(image(i-1:i+1, j-1:j+1));
            % Apply kernel
            smoothed_value = sum(sum(region .* kernel));
            smoothed_image(i, j) = uint8(smoothed_value);
        end
    end
end

function sharpened_image = sharpen_image(image)
    % Define a sharpening kernel (Laplacian kernel for edge enhancement)
    kernel = [0, -1, 0;
             -1, 5, -1;
              0, -1, 0];

    % Get image dimensions
    [height, width] = size(image);

    % Initialize output image
    sharpened_image = zeros(height, width, 'uint8');

    % Apply convolution without using built-in function
    for i = 2:height-1
        for j = 2:width-1
            % Extract 3x3 region
            region = double(image(i-1:i+1, j-1:j+1));
            % Apply kernel
            sharpened_value = sum(sum(region .* kernel));
            % Ensure pixel value is within 0-255 range
            sharpened_image(i, j) = uint8(min(max(sharpened_value, 0), 255));
        end
    end
end
