% Read an image
image = imread('F:\MATLAB_DIP\labgray.jpg');

% Set the desired output range
min_output = 0;
max_output = 255;

% Apply contrast stretching
stretched_image = contrast_stretch_manual(image, min_output, max_output);

% Display the original and stretched images
figure;
subplot(1, 2, 1); imshow(image); title('Original Image');
subplot(1, 2, 2); imshow(stretched_image); title('Contrast Stretched Image');


function stretched_image = contrast_stretch_manual(image, min_output, max_output)
    % Get the dimensions of the image
    [rows, cols, channels] = size(image);

    % Initialize the stretched image
    stretched_image = zeros(rows, cols, channels, 'uint8');

    % Find the minimum and maximum pixel values in the image
    min_input = 255;
    max_input = 0;
    for i = 1:rows
        for j = 1:cols
            for k = 1:channels
                if image(i, j, k) < min_input
                    min_input = image(i, j, k);
                end
                if image(i, j, k) > max_input
                    max_input = image(i, j, k);
                end
            end
        end
    end

    % Perform contrast stretching for each pixel
    for i = 1:rows
        for j = 1:cols
            for k = 1:channels
                stretched_image(i, j, k) = uint8(((image(i, j, k) - min_input) / (max_input - min_input)) * (max_output - min_output) + min_output);
            end
        end
    end
end
