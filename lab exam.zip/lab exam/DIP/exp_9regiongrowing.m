% Read the image and convert to grayscale
inputImage = imread('can1.jpg'); % Replace with your image file
grayImage = rgb2gray(inputImage);       % Convert to grayscale if the image is in color
grayImage = double(grayImage);          % Convert to double for computation

% Initialize parameters
threshold = 20;                         % Threshold for similarity
seedX = 100;                            % Seed X coordinate
seedY = 100;                            % Seed Y coordinate
[rows, cols] = size(grayImage);         % Get the size of the image
visited = false(rows, cols);            % Create a matrix to mark visited pixels
edgeImage = zeros(rows, cols);         % Initialize the edge image

% Initialize region with the seed pixel
region = zeros(rows, cols);
region(seedX, seedY) = 1;              % Mark the seed point

% Grow region starting from the seed point
while true
    changes = false;  % Flag to check if any new pixels were added

    % Loop through all pixels to expand region
    for i = 2:rows-1
        for j = 2:cols-1
            if region(i, j) == 1 && ~visited(i, j)
                visited(i, j) = true; % Mark the pixel as visited
                
                % Check all 8 neighbors
                for dx = -1:1
                    for dy = -1:1
                        nx = i + dx;
                        ny = j + dy;
                        
                        % Make sure the new coordinates are within bounds
                        if nx > 0 && ny > 0 && nx <= rows && ny <= cols
                            % If the neighbor is similar to the current region, add it
                            if abs(grayImage(nx, ny) - grayImage(i, j)) < threshold && region(nx, ny) == 0
                                region(nx, ny) = 1;
                                changes = true; % New pixel added to the region
                            end
                        end
                    end
                end
            end
        end
    end
    
    % Stop the process if no new pixels were added in the last iteration
    if ~changes
        break;
    end
end

% Create the edge image by marking boundaries
for i = 2:rows-1
    for j = 2:cols-1
        if region(i, j) == 1
            edgeImage(i, j) = 255; % Region boundary is marked as white
        else
            edgeImage(i, j) = 0;   % Non-region areas are marked as black
        end
    end
end

% Display the results
figure;
subplot(1,2,1); imshow(uint8(grayImage)); title('Original Image');
subplot(1,2,2); imshow(uint8(edgeImage)); title('Region Growing Edge Detection');
