% Read and convert the input image to grayscale
inputImage = imread('can1.jpg'); % Replace with your image file
grayImage = rgb2gray(inputImage);       % Convert to grayscale if it's a color image
grayImage = double(grayImage);          % Convert to double for computation

% Initialize the size of the image
[rows, cols] = size(grayImage);

% Define the kernels
RobertX = [1 0; 0 -1];  % Robert Cross gradient kernel (X direction)
RobertY = [0 1; -1 0];  % Robert Cross gradient kernel (Y direction)

PrewittX = [-1 0 1; -1 0 1; -1 0 1];  % Prewitt kernel (X direction)
PrewittY = [-1 -1 -1; 0 0 0; 1 1 1];  % Prewitt kernel (Y direction)

SobelX = [-1 0 1; -2 0 2; -1 0 1];    % Sobel kernel (X direction)
SobelY = [-1 -2 -1; 0 0 0; 1 2 1];    % Sobel kernel (Y direction)

% Initialize the gradient magnitude images
RobertEdge = zeros(rows, cols);
PrewittEdge = zeros(rows, cols);
SobelEdge = zeros(rows, cols);

% Apply the Robert Operator (X and Y gradients)
for i = 1:rows-1
    for j = 1:cols-1
        % Apply Robert X kernel
        GxR = sum(sum(grayImage(i:i+1, j:j+1) .* RobertX));
        % Apply Robert Y kernel
        GyR = sum(sum(grayImage(i:i+1, j:j+1) .* RobertY));
        % Compute gradient magnitude
        RobertEdge(i,j) = sqrt(GxR^2 + GyR^2);
    end
end

% Apply the Prewitt Operator (X and Y gradients)
for i = 2:rows-1
    for j = 2:cols-1
        % Apply Prewitt X kernel
        GxP = sum(sum(grayImage(i-1:i+1, j-1:j+1) .* PrewittX));
        % Apply Prewitt Y kernel
        GyP = sum(sum(grayImage(i-1:i+1, j-1:j+1) .* PrewittY));
        % Compute gradient magnitude
        PrewittEdge(i,j) = sqrt(GxP^2 + GyP^2);
    end
end

% Apply the Sobel Operator (X and Y gradients)
for i = 2:rows-1
    for j = 2:cols-1
        % Apply Sobel X kernel
        GxS = sum(sum(grayImage(i-1:i+1, j-1:j+1) .* SobelX));
        % Apply Sobel Y kernel
        GyS = sum(sum(grayImage(i-1:i+1, j-1:j+1) .* SobelY));
        % Compute gradient magnitude
        SobelEdge(i,j) = sqrt(GxS^2 + GyS^2);
    end
end

% Normalize the results to display correctly
RobertEdge = uint8(RobertEdge / max(RobertEdge(:)) * 255);
PrewittEdge = uint8(PrewittEdge / max(PrewittEdge(:)) * 255);
SobelEdge = uint8(SobelEdge / max(SobelEdge(:)) * 255);

% Display the results
figure;
subplot(2,2,1); imshow(uint8(grayImage)); title('Original Image');
subplot(2,2,2); imshow(RobertEdge); title('Robert Edge Detection');
subplot(2,2,3); imshow(PrewittEdge); title('Prewitt Edge Detection');
subplot(2,2,4); imshow(SobelEdge); title('Sobel Edge Detection');
