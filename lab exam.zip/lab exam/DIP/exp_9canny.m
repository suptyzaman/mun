% Read the input image
inputImage = imread('can1.jpg'); % Replace with your image file
inputImage = rgb2gray(inputImage);      % Convert to grayscale if it's a color image

% Convert the image to double for computations
inputImage = double(inputImage);

% Step 1: Apply Gaussian filter to smooth the image
% Define a 5x5 Gaussian filter
sigma = 1.4; % Standard deviation
filterSize = 5; 
[x, y] = meshgrid(-floor(filterSize/2):floor(filterSize/2));
gaussianFilter = exp(-(x.^2 + y.^2) / (2 * sigma^2));
gaussianFilter = gaussianFilter / sum(gaussianFilter(:)); % Normalize

% Convolve the image with the Gaussian filter
[rows, cols] = size(inputImage);
smoothedImage = zeros(rows, cols);
for i = 3:rows-2
    for j = 3:cols-2
        region = inputImage(i-2:i+2, j-2:j+2);
        smoothedImage(i, j) = sum(sum(region .* gaussianFilter));
    end
end

% Step 2: Compute gradients using Sobel operator
Gx = [-1 0 1; -2 0 2; -1 0 1]; % Sobel x-direction kernel
Gy = [-1 -2 -1; 0 0 0; 1 2 1]; % Sobel y-direction kernel

gradientX = zeros(rows, cols);
gradientY = zeros(rows, cols);

for i = 2:rows-1
    for j = 2:cols-1
        region = smoothedImage(i-1:i+1, j-1:j+1);
        gradientX(i, j) = sum(sum(region .* Gx));
        gradientY(i, j) = sum(sum(region .* Gy));
    end
end

% Compute gradient magnitude and direction
gradientMagnitude = sqrt(gradientX.^2 + gradientY.^2);
gradientDirection = atan2d(gradientY, gradientX); % Direction in degrees

% Normalize gradient magnitude to 0-255
gradientMagnitude = gradientMagnitude / max(gradientMagnitude(:)) * 255;

% Step 3: Non-maximum suppression
nmsImage = zeros(rows, cols);
angle = mod(gradientDirection, 180); % Convert to 0-180 degrees
for i = 2:rows-1
    for j = 2:cols-1
        % Determine the neighboring pixels to compare
        if (angle(i, j) >= 0 && angle(i, j) < 22.5) || (angle(i, j) >= 157.5 && angle(i, j) <= 180)
            neighbor1 = gradientMagnitude(i, j-1);
            neighbor2 = gradientMagnitude(i, j+1);
        elseif (angle(i, j) >= 22.5 && angle(i, j) < 67.5)
            neighbor1 = gradientMagnitude(i-1, j+1);
            neighbor2 = gradientMagnitude(i+1, j-1);
        elseif (angle(i, j) >= 67.5 && angle(i, j) < 112.5)
            neighbor1 = gradientMagnitude(i-1, j);
            neighbor2 = gradientMagnitude(i+1, j);
        else
            neighbor1 = gradientMagnitude(i-1, j-1);
            neighbor2 = gradientMagnitude(i+1, j+1);
        end
        
        % Suppress non-maximum pixels
        if gradientMagnitude(i, j) >= neighbor1 && gradientMagnitude(i, j) >= neighbor2
            nmsImage(i, j) = gradientMagnitude(i, j);
        else
            nmsImage(i, j) = 0;
        end
    end
end

% Step 4: Double threshold and edge tracking by hysteresis
highThreshold = 40; % High threshold (adjust as needed)
lowThreshold = 20;  % Low threshold (adjust as needed)

strongEdges = nmsImage > highThreshold;
weakEdges = nmsImage > lowThreshold & nmsImage <= highThreshold;

% Edge tracking by hysteresis
finalEdges = strongEdges;
for i = 2:rows-1
    for j = 2:cols-1
        if weakEdges(i, j)
            % Check if any strong edge is in the neighborhood
            if any(any(strongEdges(i-1:i+1, j-1:j+1)))
                finalEdges(i, j) = 1;
            end
        end
    end
end

% Display the results
figure;
subplot(2, 2, 1); imshow(uint8(inputImage)); title('Original Image');
subplot(2, 2, 2); imshow(uint8(smoothedImage)); title('Smoothed Image');
subplot(2, 2, 3); imshow(uint8(nmsImage)); title('Non-Maximum Suppressed');
subplot(2, 2, 4); imshow(finalEdges); title('Final Edge Detected Image');
