% Read and convert the image to grayscale
inputImage = imread('input_image.jpg');  % Replace with your image file
grayImage = rgb2gray(inputImage);        % Convert to grayscale if the image is color
grayImage = double(grayImage);           % Convert to double for computation

% Parameters
threshold = 50;                          % Threshold for splitting/merging criterion (variance threshold)
minRegionSize = 8;                       % Minimum region size for merging (in pixels)
maxRegionSize = 100;                     % Maximum size to prevent splitting too much
splitThreshold = 10;                     % Variance threshold for splitting a region
regionMap = zeros(size(grayImage));      % Initialize region map

% Image dimensions
[rows, cols] = size(grayImage);

% Function to split and merge a region based on variance
function regionMap = splitMerge(image, regionMap, threshold, x, y, width, height)
    % Calculate the mean and variance of the region
    region = image(x:x+width-1, y:y+height-1);
    regionMean = mean(region(:));
    regionVar = var(region(:));
    
    % If variance exceeds the threshold and region is large enough, split further
    if regionVar > threshold && width > 2 && height > 2
        midX = floor(width / 2);
        midY = floor(height / 2);
        
        % Split region into 4 smaller sub-regions and recursively apply splitMerge
        regionMap = splitMerge(image, regionMap, threshold, x, y, midX, midY);                    % Top-left
        regionMap = splitMerge(image, regionMap, threshold, x, y + midY, midX, height - midY);     % Top-right
        regionMap = splitMerge(image, regionMap, threshold, x + midX, y, width - midX, midY);       % Bottom-left
        regionMap = splitMerge(image, regionMap, threshold, x + midX, y + midY, width - midX, height - midY);  % Bottom-right
    else
        % Mark the region as homogeneous
        regionMap(x:x+width-1, y:y+height-1) = 1;
    end
end

% Start region splitting from the full image
regionMap = splitMerge(grayImage, regionMap, splitThreshold, 1, 1, rows, cols);

% Merge small regions if their means are similar
for i = 1:rows-1
    for j = 1:cols-1
        if regionMap(i, j) == 1 && regionMap(i+1, j) == 1 && regionMap(i, j+1) == 1
            % Merge neighboring similar regions based on pixel intensity values
            if abs(grayImage(i, j) - grayImage(i+1, j)) < threshold && abs(grayImage(i, j) - grayImage(i, j+1)) < threshold
                regionMap(i, j) = 1;  % Mark as edge-free
            end
        end
    end
end

% Create the final edge-detection result
edgeImage = zeros(size(grayImage));

% Mark boundaries of regions as edges
for i = 2:rows-1
    for j = 2:cols-1
        if regionMap(i, j) ~= regionMap(i-1, j) || regionMap(i, j) ~= regionMap(i, j-1)
            edgeImage(i, j) = 255;  % Mark as boundary (edge)
        else
            edgeImage(i, j) = 0;    % Inside homogeneous regions
        end
    end
end

% Display the original image and edge-detection result
figure;
subplot(1,2,1); imshow(uint8(grayImage)); title('Original Image');
subplot(1,2,2); imshow(uint8(edgeImage)); title('Region Splitting and Merging Edge Detection');
