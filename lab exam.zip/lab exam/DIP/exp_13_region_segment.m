% Load grayscale image
image = imread('screenshot.png'); % Replace with your image file
if size(image, 3) == 3
    image = rgb2gray(image); % Convert to grayscale
end

% Display the original image
figure;
subplot(1, 2, 1);
imshow(image);
title('Original Image');

% Initialize parameters
threshold = 15; % Intensity difference threshold
seedPoint = [100, 150]; % Replace with desired seed point coordinates (row, column)

% Region growing function
segmentedRegion = regionGrowing(image, seedPoint, threshold);

% Display the segmented region
subplot(1, 2, 2);
imshow(segmentedRegion);
title('Segmented Region');

% Function definition for region growing
function region = regionGrowing(image, seed, threshold)
    [rows, cols] = size(image);
    region = false(rows, cols); % Initialize region as a binary mask
    region(seed(1), seed(2)) = true; % Mark the seed point in the region

    % Get the intensity value of the seed point
    seedValue = image(seed(1), seed(2));
    
    % Stack to store pixels to be checked
    pixelStack = seed;
    
    % Region growing loop
    while ~isempty(pixelStack)
        % Pop a pixel from the stack
        currentPixel = pixelStack(end, :);
        pixelStack(end, :) = [];
        
        % Get neighbors of the current pixel
        neighbors = getNeighbors(currentPixel, rows, cols);
        
        for i = 1:size(neighbors, 1)
            neighbor = neighbors(i, :);
            if ~region(neighbor(1), neighbor(2)) % Check if not already in region
                % Check similarity condition
                if abs(double(image(neighbor(1), neighbor(2))) - double(seedValue)) <= threshold
                    % Add to the region
                    region(neighbor(1), neighbor(2)) = true;
                    % Push the neighbor to the stack
                    pixelStack = [pixelStack; neighbor];
                end
            end
        end
    end
end

% Function to get 8-connected neighbors of a pixel
function neighbors = getNeighbors(pixel, rows, cols)
    x = pixel(1);
    y = pixel(2);
    neighbors = [];
    for dx = -1:1
        for dy = -1:1
            if dx == 0 && dy == 0
                continue;
            end
            nx = x + dx;
            ny = y + dy;
            if nx >= 1 && nx <= rows && ny >= 1 && ny <= cols
                neighbors = [neighbors; nx, ny];
            end
        end
    end
end
