% Load the image
image = imread('pepper.jpg'); % Replace 'your_image.jpg' with the actual image path

% Check if the image is grayscale or RGB
if size(image, 3) == 1
    % For Grayscale image
    figure;
    histogram(image, 256); % 256 bins for pixel intensity
    title('Histogram of Grayscale Image');
    xlabel('Pixel Intensity');
    ylabel('Frequency');
else
    % For RGB image
    redChannel = image(:,:,1); % Red channel
    greenChannel = image(:,:,2); % Green channel
    blueChannel = image(:,:,3); % Blue channel
    
    % Plot histograms for each channel
    figure;
    subplot(3, 1, 1);
    histogram(redChannel, 256, 'FaceColor', 'r');
    title('Red Channel Histogram');
    xlabel('Pixel Intensity');
    ylabel('Frequency');
    
    subplot(3, 1, 2);
    histogram(greenChannel, 256, 'FaceColor', 'g');
    title('Green Channel Histogram');
    xlabel('Pixel Intensity');
    ylabel('Frequency');
    
    subplot(3, 1, 3);
    histogram(blueChannel, 256, 'FaceColor', 'b');
    title('Blue Channel Histogram');
    xlabel('Pixel Intensity');
    ylabel('Frequency');
end
