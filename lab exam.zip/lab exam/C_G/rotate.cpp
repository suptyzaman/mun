#include <graphics.h>
#include <conio.h>
#include <math.h>
#include <iostream>

using namespace std;

// Function to rotate a point (used for rotating polygons like triangle, rectangle)
void rotatePoint(float& x, float& y, float angle) {
    float rad = angle * (M_PI / 180.0);  // Convert angle to radians
    float x_new = x * cos(rad) - y * sin(rad);
    float y_new = x * sin(rad) + y * cos(rad);
    x = x_new;
    y = y_new;
}

// Function to rotate and draw a triangle
void rotateTriangle(float angle) {
    // Initial coordinates of the triangle
    float x1 = 100, y1 = 100;
    float x2 = 150, y2 = 50;
    float x3 = 200, y3 = 100;

    // Original triangle
    line(x1 + 200, y1 + 200, x2 + 200, y2 + 200);
    line(x2 + 200, y2 + 200, x3 + 200, y3 + 200);
    line(x3 + 200, y3 + 200, x1 + 200, y1 + 200);

    // Rotate each point
    rotatePoint(x1, y1, angle);
    rotatePoint(x2, y2, angle);
    rotatePoint(x3, y3, angle);

    // Draw rotated triangle
    line(x1 + 200, y1 + 200, x2 + 200, y2 + 200);
    line(x2 + 200, y2 + 200, x3 + 200, y3 + 200);
    line(x3 + 200, y3 + 200, x1 + 200, y1 + 200);
}

// Function to rotate and draw a rectangle
void rotateRectangle(float angle) {
    // Initial coordinates of the rectangle
    float x1 = 100, y1 = 100;
    float x2 = 200, y2 = 100;
    float x3 = 200, y3 = 200;
    float x4 = 100, y4 = 200;

    // Original rectangle
    rectangle(x1 + 200, y1 + 200, x3 + 200, y3 + 200);

    // Rotate each point
    rotatePoint(x1, y1, angle);
    rotatePoint(x2, y2, angle);
    rotatePoint(x3, y3, angle);
    rotatePoint(x4, y4, angle);

    // Draw rotated rectangle
    line(x1 + 200, y1 + 200, x2 + 200, y2 + 200);
    line(x2 + 200, y2 + 200, x3 + 200, y3 + 200);
    line(x3 + 200, y3 + 200, x4 + 200, y4 + 200);
    line(x4 + 200, y4 + 200, x1 + 200, y1 + 200);
}

// Function to draw and rotate a circle
void rotateCircle(float angle) {
    // A circle does not change its shape when rotated. Only the center moves.
    int radius = 50;
    float centerX = 150, centerY = 150;

    // Draw original circle
    circle(centerX + 200, centerY + 200, radius);

    // Rotate center point
    rotatePoint(centerX, centerY, angle);

    // Draw rotated circle
    circle(centerX + 200, centerY + 200, radius);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int choice;
    float angle;

    // Menu for shape selection
    cout << "Select the object to rotate:" << endl;
    cout << "1. Triangle" << endl;
    cout << "2. Rectangle" << endl;
    cout << "3. Circle" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    cout << "Enter the angle of rotation: ";
    cin >> angle;

    // Clear screen for each selection
    cleardevice();

    switch (choice) {
        case 1:
            rotateTriangle(angle);
            break;
        case 2:
            rotateRectangle(angle);
            break;
        case 3:
            rotateCircle(angle);
            break;
        default:
            cout << "Invalid choice!" << endl;
    }

    getch();
    closegraph();
    return 0;
}
