#include <graphics.h>
#include <conio.h>
#include <iostream>

using namespace std;

void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);
}

void mirrorPoint(int &x, int &y, int axisX, int axisY, bool mirrorX, bool mirrorY) {
    if (mirrorX) {
        y = 2 * axisY - y; // Mirror across X-axis
    }
    if (mirrorY) {
        x = 2 * axisX - x; // Mirror across Y-axis
    }
}

void mirrorTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int axisX, int axisY, bool mirrorX, bool mirrorY) {
    // Create temporary points to hold mirrored coordinates
    int mx1 = x1, my1 = y1, mx2 = x2, my2 = y2, mx3 = x3, my3 = y3;

    // Apply mirroring
    mirrorPoint(mx1, my1, axisX, axisY, mirrorX, mirrorY);
    mirrorPoint(mx2, my2, axisX, axisY, mirrorX, mirrorY);
    mirrorPoint(mx3, my3, axisX, axisY, mirrorX, mirrorY);

    // Draw the mirrored triangle
    drawTriangle(mx1, my1, mx2, my2, mx3, my3);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    int x1 = 150, y1 = 100, x2 = 200, y2 = 50, x3 = 250, y3 = 100; // Original triangle
    int axisX = 200, axisY = 150;                                   // Center for mirroring

    while (true) {
        cleardevice();

        // Draw the original triangle
        drawTriangle(x1, y1, x2, y2, x3, y3);

        cout << "1. Mirror Triangle along X-axis\n";
        cout << "2. Mirror Triangle along Y-axis\n";
        cout << "3. Mirror Triangle along both X and Y axes\n";
        cout << "4. Exit\n";
        cout << "Choose an option: ";

        int choice;
        cin >> choice;

        if (choice == 4) {
            break;
        }

        // Show both original and mirrored triangles together
        switch (choice) {
            case 1: {
                // Mirror along X-axis
                mirrorTriangle(x1, y1, x2, y2, x3, y3, axisX, axisY, true, false);
                break;
            }
            case 2: {
                // Mirror along Y-axis
                mirrorTriangle(x1, y1, x2, y2, x3, y3, axisX, axisY, false, true);
                break;
            }
            case 3: {
                // Mirror along both X and Y axes
                mirrorTriangle(x1, y1, x2, y2, x3, y3, axisX, axisY, true, true);
                break;
            }
            default:
                cout << "Invalid choice!\n";
                continue;
        }

        cout << "Press any key to continue...\n";
        getch();
    }

    closegraph();
    return 0;
}
