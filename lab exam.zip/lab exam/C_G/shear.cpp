#include <iostream>
#include <graphics.h>
#include <conio.h>

using namespace std;

// Function to draw a rectangle (or any object you want to shear)
void drawObject(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int color) {
    setcolor(color);
    line(x1, y1, x2, y2); // Top line
    line(x2, y2, x3, y3); // Right line
    line(x3, y3, x4, y4); // Bottom line
    line(x4, y4, x1, y1); // Left line
}

// Function to apply shearing transformation
void applyShear(int &x, int &y, float shX, float shY) {
    int newX = x + shX * y;
    int newY = y + shY * x;
    x = newX;
    y = newY;
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    // Coordinates of the object (rectangle)
    int x1 = 100, y1 = 100;
    int x2 = 200, y2 = 100;
    int x3 = 200, y3 = 200;
    int x4 = 100, y4 = 200;

    // Draw the original object
    drawObject(x1, y1, x2, y2, x3, y3, x4, y4, WHITE);
    cout << "Original object drawn. Press any key to shear." << endl;


    // Choose shear type
    int option;
    float shX = 0, shY = 0;
    cout << "Choose Shear Type:" << endl;
    cout << "1. X Shear" << endl;
    cout << "2. Y Shear" << endl;
    cout << "3. Both X and Y Shear" << endl;
    cin >> option;

    // Input shear factors
    if (option == 1) {
        cout << "Enter X shear factor: ";
        cin >> shX;
    } else if (option == 2) {
        cout << "Enter Y shear factor: ";
        cin >> shY;
    } else if (option == 3) {
        cout << "Enter X shear factor: ";
        cin >> shX;
        cout << "Enter Y shear factor: ";
        cin >> shY;
    }

    // Apply shear to each vertex
    applyShear(x1, y1, shX, shY);
    applyShear(x2, y2, shX, shY);
    applyShear(x3, y3, shX, shY);
    applyShear(x4, y4, shX, shY);

    // Clear the previous screen
    cleardevice();

    // Draw the sheared object
    drawObject(x1, y1, x2, y2, x3, y3, x4, y4, RED);
    cout << "Sheared object drawn. Press any key to exit." << endl;

    getch();
    closegraph();
    return 0;
}
