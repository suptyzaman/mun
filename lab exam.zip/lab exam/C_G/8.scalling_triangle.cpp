#include <graphics.h>
#include <iostream>
using namespace std;

// Function to draw a triangle
void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int color) {
    setcolor(color);
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);
}

int main() {
    // Initialize graphics
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    // Original triangle vertices
    int x1, y1, x2, y2, x3, y3;
    cout << "Enter the Coordinates of the Triangle's Vertex-1 (x1,y1): ";
    cin >> x1 >> y1;
    cout << "Enter the Coordinates of the Triangle's Vertex-2 (x2,y2): ";
    cin >> x2 >> y2;
    cout << "Enter the Coordinates of the Triangle's Vertex-3 (x3,y3): ";
    cin >> x3 >> y3;

    // Scaling factors
    float sx, sy;

    // Draw the original triangle
    drawTriangle(x1, y1, x2, y2, x3, y3, WHITE);
    outtextxy(x1, y1, (char*)"Original");

    // Ask the user for scaling factors
    cout << "Enter scaling factor for x-axis (sx): ";
    cin >> sx;
    cout << "Enter scaling factor for y-axis (sy): ";
    cin >> sy;

    // Apply scaling
    int x1_scaled = x1 * sx;
    int y1_scaled = y1 * sy;
    int x2_scaled = x2 * sx;
    int y2_scaled = y2 * sy;
    int x3_scaled = x3 * sx;
    int y3_scaled = y3 * sy;

    // Draw the scaled triangle
    drawTriangle(x1_scaled, y1_scaled, x2_scaled, y2_scaled, x3_scaled, y3_scaled, YELLOW);
    outtextxy(x1_scaled, y1_scaled, (char*)"Scaled");

    // Wait for a key press and close the graphics window
    getch();
    closegraph();

    return 0;
}
