#include <iostream>
#include <graphics.h>
#include <limits>
#include <cmath>

using namespace std;

const int MAX_X = 640;
const int MAX_Y = 480;

// Z-buffer array
float zBuffer[MAX_X][MAX_Y];

// Function to initialize the Z-buffer to infinity
void initializeZBuffer() {
    for (int i = 0; i < MAX_X; i++) {
        for (int j = 0; j < MAX_Y; j++) {
            zBuffer[i][j] = numeric_limits<float>::infinity();
        }
    }
}

// Function to draw a pixel using Z-buffering
void drawPixel(int x, int y, float z, int color) {
    if (x >= 0 && x < MAX_X && y >= 0 && y < MAX_Y) {
        if (z < zBuffer[x][y]) {
            zBuffer[x][y] = z;
            putpixel(x, y, color);
        }
    }
}

// Function to interpolate between two values (for depth and other calculations)
float interpolate(float x0, float x1, float y0, float y1, float x) {
    return y0 + (y1 - y0) * ((x - x0) / (x1 - x0));
}

// Rasterization of a triangle using Z-buffering
void drawTriangle(int x1, int y1, float z1, int x2, int y2, float z2, int x3, int y3, float z3, int color) {
    // Sort vertices by y-coordinate (y1 <= y2 <= y3)
    if (y1 > y2) {
        swap(x1, x2);
        swap(y1, y2);
        swap(z1, z2);
    }
    if (y1 > y3) {
        swap(x1, x3);
        swap(y1, y3);
        swap(z1, z3);
    }
    if (y2 > y3) {
        swap(x2, x3);
        swap(y2, y3);
        swap(z2, z3);
    }

    // Rasterize the triangle
    for (int y = y1; y <= y3; y++) {
        float xL, xR, zL, zR;

        if (y < y2) {
            xL = interpolate(y1, y2, x1, x2, y);
            zL = interpolate(y1, y2, z1, z2, y);
        } else {
            xL = interpolate(y2, y3, x2, x3, y);
            zL = interpolate(y2, y3, z2, z3, y);
        }

        xR = interpolate(y1, y3, x1, x3, y);
        zR = interpolate(y1, y3, z1, z3, y);

        if (xL > xR) {
            swap(xL, xR);
            swap(zL, zR);
        }

        for (int x = xL; x <= xR; x++) {
            float z = interpolate(xL, xR, zL, zR, x);
            drawPixel(x, y, z, color);
        }
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    // Initialize Z-buffer
    initializeZBuffer();

    // Draw two triangles with different depths
    drawTriangle(100, 100, 0.5, 200, 100, 0.5, 150, 200, 0.5, GREEN);  // Closer triangle
    drawTriangle(120, 120, 1.0, 220, 120, 1.0, 170, 220, 1.0, RED);    // Farther triangle

    getch();
    closegraph();

    return 0;
}
