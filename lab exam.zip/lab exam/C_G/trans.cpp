#include <graphics.h>
#include <iostream>

using namespace std;

void translateRectangle(int x, int y, int tx, int ty) {
    // Original Rectangle
    rectangle(x, y, x + 100, y + 50);

    // Translated Rectangle
    rectangle(x + tx, y + ty, x + 100 + tx, y + 50 + ty);
}

void translateCircle(int x, int y, int r, int tx, int ty) {
    // Original Circle
    circle(x, y, r);

    // Translated Circle
    circle(x + tx, y + ty, r);
}

void translateTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int tx, int ty) {
    // Original Triangle
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);

    // Translated Triangle
    line(x1 + tx, y1 + ty, x2 + tx, y2 + ty);
    line(x2 + tx, y2 + ty, x3 + tx, y3 + ty);
    line(x3 + tx, y3 + ty, x1 + tx, y1 + ty);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int choice, tx, ty;

    cout << "Choose the shape to translate: \n1. Rectangle\n2. Circle\n3. Triangle\n";
    cin >> choice;

    cout << "Enter the translation factors (tx, ty): ";
    cin >> tx >> ty;

    switch (choice) {
    case 1: // Rectangle
        translateRectangle(100, 100, tx, ty);
        break;
    case 2: // Circle
        translateCircle(200, 200, 50, tx, ty);
        break;
    case 3: // Triangle
        translateTriangle(250, 250, 300, 350, 200, 350, tx, ty);
        break;
    default:
        cout << "Invalid choice!";
    }

    getch();
    closegraph();
    return 0;
}
