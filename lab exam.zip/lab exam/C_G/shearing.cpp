
#include <graphics.h>
#include <iostream>
using namespace std;

// Function to draw a rectangle
void drawRectangle(int x1, int y1, int x2, int y2, int color) {
    setcolor(color);
    rectangle(x1, y1, x2, y2);
}

int main() {
    // Initialize graphics
    int gd = DETECT, gm;
    initgraph(&gd, &gm, (char*)"");

    // Original rectangle coordinates
    int x1 = 100, y1 = 100, x2 = 200, y2 = 150;

    // Draw the original rectangle
    drawRectangle(x1, y1, x2, y2, WHITE);
    outtextxy(x1, y1 - 10, (char*)"Original");

    // User input for shearing
    int option;
    float shX = 0, shY = 0;
    cout << "Choose the shearing operation:" << endl;
    cout << "1. Shear along X-axis" << endl;
    cout << "2. Shear along Y-axis" << endl;
    cout << "3. Shear along both axes" << endl;
    cout << "Enter your choice (1/2/3): ";
    cin >> option;

    // Perform shearing based on user choice
    if (option == 1) {
        // Shear along X-axis
        cout << "Enter the shear factor for X-axis: ";
        cin >> shX;

        // Apply X-shearing transformation
        int x1_new = x1 + shX * y1;
        int x2_new = x2 + shX * y2;

        drawRectangle(x1_new, y1, x2_new, y2, YELLOW);
        outtextxy(x1_new, y1 - 10, (char*)"Sheared X-axis");
    } else if (option == 2) {
        // Shear along Y-axis
        cout << "Enter the shear factor for Y-axis: ";
        cin >> shY;

        // Apply Y-shearing transformation
        int y1_new = y1 + shY * x1;
        int y2_new = y2 + shY * x2;

        drawRectangle(x1, y1_new, x2, y2_new, GREEN);
        outtextxy(x1, y1_new - 10, (char*)"Sheared Y-axis");
    } else if (option == 3) {
        // Shear along both axes
        cout << "Enter the shear factor for X-axis: ";
        cin >> shX;
        cout << "Enter the shear factor for Y-axis: ";
        cin >> shY;

        // Apply X and Y-shearing transformation
        int x1_new = x1 + shX * y1;
        int x2_new = x2 + shX * y2;
        int y1_new = y1 + shY * x1;
        int y2_new = y2 + shY * x2;

        drawRectangle(x1_new, y1_new, x2_new, y2_new, RED);
        outtextxy(x1_new, y1_new - 10, (char*)"Sheared Both Axes");
    } else {
        cout << "Invalid option! Exiting." << endl;
    }

    // Wait for a key press and close the graphics window
    getch();
    closegraph();

    return 0;
}
