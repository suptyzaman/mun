import pandas as pd

data = {
        'name': ['rabbi', 'rakib','raihan','mehedi'],
        'age': ['23','24','42','20'],
        'place': ['bogura','mymensingh','mymensingh','mymensingh']
        }
df = pd.DataFrame.from_dict(data)
print('Created Dataframe')
print(df)

df.to_csv("data.csv")

df.to_excel('data.xlsx')

df.to_json('data.json')

df = pd.read_csv("data.csv")
print("csv file read")
print(df)

df = pd.read_excel("data.xlsx")
print("excel file read")
print(df)